package org.evaluation.web.dto.rest;

import java.io.Serializable;

public class CurrencyRequestDTO implements Serializable {
	private static final long serialVersionUID = -8088842448464747328L;


}
