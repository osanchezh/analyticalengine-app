package org.evaluation.web.dto.rest;

import java.io.Serializable;

public class CurrencyResponseDTO implements Serializable {

	private static final long serialVersionUID = -8855160742718856111L;
    
}
