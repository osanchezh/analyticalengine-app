ExplorerCanvas
Copyright 2006 Google Inc.

-------------------------------------------------------------------------------
DESCRIPTION

Firefox, Safari and Opera 9 support the canvas tag to allow 2D command-based 
drawing operations. ExplorerCanvas brings the same functionality to Internet 
Explorer; web developers only need to include a single script tag in their 
existing canvas webpages to enable this support.


-------------------------------------------------------------------------------
INSTALLATION

Include the ExplorerCanvas tag in the same directory as your HTML files, and 
add the following code to your page, preferably in the <head> tag.

<!--[if IE]><script type="text/javascript" src="excanvas.js"></script><![endif]-->

If you run into trouble, please look at the included example code to see how
to best implement this