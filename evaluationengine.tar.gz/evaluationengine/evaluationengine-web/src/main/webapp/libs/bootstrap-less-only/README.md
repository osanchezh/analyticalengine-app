Twitter Bootstrap <small>(LESS only)</small>
=================

This is a Bower's component with [Bootstrap](http://getbootstrap.com/) containing LESS and font libraries only.
Thought to fit well with [Angular-UI Bootstrap](https://github.com/angular-ui/bootstrap-bower).

Current version is v3.3.7

# Installation

1- `bower install bootstrap-less-only`