'use strict';
angular
    .module('evaluationEngineApp', [
        'ngAnimate',
        'ngCookies',
        'ngResource',
        'ngRoute',
        'ngSanitize',
        'ngTouch',
        'webix'
    ]);